class Hello():
    def __init__(self):
        Hello.sas = 0

if Hello():
    print("Hello")