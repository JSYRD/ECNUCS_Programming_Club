public class test{
    public static void main(String[] args) {
        String a = new String("yangrundong");
        String b = new String("yangrundong");

        String str = "yangrundong";
        String tempStr = "yangrundong";

        System.out.println(a==b);
        System.out.println(a.equals(b));
        // Test d = new Test();
        // System.out.println(c==d);
        // System.out.println(c.equals(d));
    }
}
class Test{
    
}