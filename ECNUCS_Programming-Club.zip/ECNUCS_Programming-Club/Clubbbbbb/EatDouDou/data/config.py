import pygame
MARGIN = 40
ROW = COL = 30
BG_COLOR=(0,0,0)
SIZE = (WIDTH,HEIGHT) = (1280,720)
FPS = 144
COMPASS = [(0,-1), (0, 1), (-1, 0), (1, 0)]
print(ROW)
print(COL)