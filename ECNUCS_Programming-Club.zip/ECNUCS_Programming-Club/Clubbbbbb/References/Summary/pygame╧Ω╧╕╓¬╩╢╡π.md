# Pygame详细知识点

* [pygame最小开发框架](./pygame最小开发框架.html)   <a target="_blank" href="./pygame最小开发框架.pdf">下载PDF</a>

* [pygame窗口](./pygame窗口.html)   <a target="_blank" href="./pygame窗口.pdf">下载PDF</a>

* [pygame时钟](./pygame时钟.html)   <a target="_blank" href="./pygame时钟.pdf">下载PDF</a>

* [pygame精灵类](./pygame精灵类.html)   <a target="_blank" href="./pygame精灵类.pdf">下载PDF</a>