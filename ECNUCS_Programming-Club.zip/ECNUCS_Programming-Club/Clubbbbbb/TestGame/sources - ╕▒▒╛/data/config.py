import pygame
BG_COLOR=[pygame.Color(48,128,20),pygame.Color(65,105,225),pygame.Color(255,153,18)]
pygame.display.init()
SIZE = (WIDTH,HEIGHT) = (1920,1080)
FPS = 60
g=0.2