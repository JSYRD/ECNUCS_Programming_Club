import pygame
BG_COLOR=pygame.Color(255,255,255)
SIZE = (WIDTH,HEIGHT) = (1080,720)
FPS = 144
g=0.2