L = range(1,10)
print(L)