#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    scanf("%d",&a);
    a=10;
    int list[10];
    printf("%d",a);
    return 0;
}
