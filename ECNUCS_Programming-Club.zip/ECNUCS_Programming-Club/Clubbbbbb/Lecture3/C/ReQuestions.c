#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define N 100
int main(){
    char a='A';
    printf("%c",a);
}